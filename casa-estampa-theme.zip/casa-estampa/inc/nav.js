/**
 * nav.js - Casa Estampa
 * Toggle do menu mobile + busca. Replica o buildGlobalNavScript
 * e o comportamento de busca do site atual, em vanilla JS.
 */
(function () {
	'use strict';

	function setupNavbar(navbar) {
		var toggle = navbar.querySelector('.navbar-toggle');
		var menu = navbar.querySelector('.navbar-nav');
		if (!toggle || !menu || toggle.dataset.ceReady === '1') return;
		toggle.dataset.ceReady = '1';

		if (!menu.id) menu.id = toggle.getAttribute('aria-controls') || 'navbar-mobile-menu';
		toggle.setAttribute('aria-controls', menu.id);

		function setOpen(open) {
			navbar.classList.toggle('is-menu-open', open);
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			document.documentElement.classList.toggle('ce-menu-open', open);
		}

		toggle.addEventListener('click', function () {
			setOpen(!navbar.classList.contains('is-menu-open'));
		});
		menu.addEventListener('click', function (event) {
			if (event.target.closest('a')) setOpen(false);
		});
		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape') setOpen(false);
		});
		document.addEventListener('click', function (event) {
			if (!navbar.contains(event.target)) setOpen(false);
		});
		window.addEventListener('resize', function () {
			if (window.innerWidth > 1024) setOpen(false);
		}, { passive: true });
	}

	function setupSearch(navbar) {
		var toggle = navbar.querySelector('.navbar-search-toggle');
		var form = navbar.querySelector('.navbar-search-form');
		if (!toggle || !form || toggle.dataset.ceReady === '1') return;
		toggle.dataset.ceReady = '1';

		toggle.addEventListener('click', function (event) {
			event.stopPropagation();
			var open = navbar.classList.toggle('is-open');
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open) {
				var input = form.querySelector('.navbar-search-input');
				if (input) window.setTimeout(function () { input.focus(); }, 50);
			}
		});
	}

	function boot() {
		document.querySelectorAll('.navbar').forEach(function (nav) {
			setupNavbar(nav);
			setupSearch(nav);
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot, { once: true });
	} else {
		boot();
	}
})();
