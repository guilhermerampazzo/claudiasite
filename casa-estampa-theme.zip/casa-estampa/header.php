<?php
/**
 * header.php - Casa Estampa
 *
 * Header global. Valores dinamicos vindos do Customizer / Menus do WP:
 * - Logo        -> Aparência > Personalizar > Casa Estampa - Logo
 * - Menu        -> Aparência > Menus (Menu Principal)
 * - Redes       -> Personalizar > Casa Estampa - Redes sociais
 * - Busca/toggle-> gerados pelo tema
 * - CTA         -> Personalizar > Casa Estampa - Contato / CTA
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<nav class="navbar">

	<!-- Social bar (editavel no Customizer > Redes sociais) -->
	<div class="navbar-social">
		<?php if ( casa_estamp_custom( 'cea_instagram' ) ) : ?>
			<a href="<?php echo esc_url( casa_estamp_custom( 'cea_instagram' ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><i class="ti ti-brand-instagram" aria-hidden="true"></i></a>
		<?php endif; ?>
		<?php if ( casa_estamp_custom( 'cea_facebook' ) ) : ?>
			<a href="<?php echo esc_url( casa_estamp_custom( 'cea_facebook' ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><i class="ti ti-brand-facebook" aria-hidden="true"></i></a>
		<?php endif; ?>
		<?php if ( casa_estamp_custom( 'cea_pinterest' ) ) : ?>
			<a href="<?php echo esc_url( casa_estamp_custom( 'cea_pinterest' ) ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Pinterest"><i class="ti ti-brand-pinterest" aria-hidden="true"></i></a>
		<?php endif; ?>
	</div>

	<!-- Logo (editavel no Customizer > Logo) -->
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-logo">
		<img class="site-logo-icon" src="<?php echo esc_url( casa_estamp_logo_icon_url() ); ?>" alt="">
		<img class="site-logo-lettering" src="<?php echo esc_url( casa_estamp_logo_lettering_url() ); ?>" alt="<?php bloginfo( 'name' ); ?>">
	</a>

	<!-- Menu principal (editavel em Aparência > Menus) -->
	<?php casa_estamp_render_menu(); ?>

	<!-- Busca -->
	<div class="navbar-search">
		<button class="navbar-search-toggle" type="button" aria-label="Buscar no site" aria-expanded="false"><i class="ti ti-search" aria-hidden="true"></i></button>
		<form class="navbar-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="search" class="navbar-search-input" placeholder="Buscar produtos, albuns..." aria-label="Buscar produtos" name="s">
			<div class="navbar-search-results" hidden></div>
		</form>
	</div>

	<!-- Toggle menu mobile -->
	<button class="navbar-toggle" type="button" aria-label="Abrir menu" aria-expanded="false" aria-controls="navbar-mobile-menu"><span></span><span></span><span></span></button>

	<!-- CTA WhatsApp (editavel no Customizer > Contato / CTA) -->
	<a href="<?php echo esc_url( casa_estamp_cta_href() ); ?>" class="navbar-cta navbar-wa"><i class="ti ti-brand-whatsapp" aria-hidden="true"></i> <?php echo esc_html( casa_estamp_custom( 'cea_cta_label' ) ); ?></a>

</nav>

<main id="content" class="site-content">
