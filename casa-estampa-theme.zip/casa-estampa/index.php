<?php
/**
 * index.php - Casa Estampa
 *
 * Template padrao (fallback). A Casa Estampa usara Elementor para
 * construir o conteudo das paginas; este template apenas renderiza
 * o que a pagina do WordPress/Elemenentor produzir dentro de <main>.
 */
get_header();
?>
<div class="entry-content" style="min-height:40vh;padding:40px clamp(18px,4vw,56px);">
	<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			the_content();
		}
	}
	?>
</div>
<?php
get_footer();
