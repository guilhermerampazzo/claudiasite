<?php
/**
 * footer.php - Casa Estampa
 *
 * Footer global. Valores dinamicos vindos do Customizer:
 * - Logo          -> Personalizar > Casa Estampa - Logo
 * - Menu "Explore"-> Aparência > Menus (reutiliza o Menu Principal)
 * - Contato/site/cidade/marca -> Personalizar > Casa Estampa - Contato / CTA
 */
?>
</main>

<footer class="footer ce-site-footer">
	<div class="ce-footer-main">

		<!-- Brand / logo -->
		<div class="ce-footer-brand">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'Página inicial da Casa Estampa', 'casa-estampa' ); ?>">
				<img class="ce-footer-icon" src="<?php echo esc_url( casa_estamp_logo_icon_url() ); ?>" alt="">
				<img class="ce-footer-lettering" src="<?php echo esc_url( casa_estamp_logo_lettering_url() ); ?>" alt="<?php bloginfo( 'name' ); ?>">
			</a>
		</div>

		<!-- Nav Explore -->
		<nav class="ce-footer-nav" aria-label="<?php esc_attr_e( 'Navegação do rodapé', 'casa-estampa' ); ?>">
			<strong><?php esc_html_e( 'Explore', 'casa-estampa' ); ?></strong>
			<div>
				<?php
				if ( has_nav_menu( 'primary' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'container'      => false,
							'items_wrap'     => '%3$s',
							'depth'          => 1,
							'fallback_cb'    => '__return_empty_string',
						)
					);
				} else {
					echo casa_estamp_footer_menu(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- links ja escapados
				}
				?>
			</div>
		</nav>

		<!-- Contato / Atendimento -->
		<div class="ce-footer-contact">
			<strong><?php esc_html_e( 'Atendimento', 'casa-estampa' ); ?></strong>
			<a href="<?php echo esc_url( casa_estamp_cta_href() ); ?>"><i class="ti ti-brand-whatsapp" aria-hidden="true"></i><?php echo esc_html( casa_estamp_custom( 'cea_footer_contact' ) ); ?></a>
			<span><?php echo esc_html( casa_estamp_custom( 'cea_footer_site' ) ); ?></span>
			<small><?php echo esc_html( casa_estamp_custom( 'cea_footer_city' ) ); ?></small>
		</div>

	</div>

	<div class="ce-footer-bottom">
		<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( casa_estamp_custom( 'cea_footer_brand' ) ); ?>. <?php esc_html_e( 'Todos os direitos reservados.', 'casa-estampa' ); ?></span>
		<a href="<?php echo esc_url( casa_estamp_cta_href() ); ?>"><?php esc_html_e( 'Falar com a Casa Estampa', 'casa-estampa' ); ?> <i class="ti ti-arrow-up-right" aria-hidden="true"></i></a>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
