<?php
/**
 * Casa Estampa theme - functions.php
 *
 * Tema WordPress da Casa Estampa Interiores, 100% editavel pelo painel:
 * - Menu  -> Aparência > Menus (wp_nav_menu)
 * - Logo, CTA/WhatsApp, redes sociais, telefone, textos do footer
 *        -> Aparência > Personalizar (Customizer API nativa)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CASA_ESTAMP_VERSION', '1.0.0' );
define( 'CASA_ESTAMP_FONT', 'Montserrat:wght@400;500;600;700' );

/**
 * Valores padrao do tema (usados como fallback ate o usuario editar).
 */
function casa_estamp_defaults() {
	return array(
		'logo_icon'      => get_template_directory_uri() . '/assets/logo-icone.svg',
		'logo_lettering' => get_template_directory_uri() . '/assets/logo-letra.svg',
		'cta_label'      => 'Falar agora',
		'cta_href'       => 'https://api.whatsapp.com/send?phone=5521999886842',
		'social_instagram' => 'https://www.instagram.com/casaestampa/',
		'social_facebook'  => 'https://www.facebook.com/casaestampainteriores',
		'social_pinterest' => 'https://br.pinterest.com/casaestampa/',
		'footer_contact' => 'Rio de Janeiro - (21) 99988-6842',
		'footer_site'    => 'casaestampa.com',
		'footer_city'    => 'Rio de Janeiro',
		'footer_brand'   => 'Casa Estampa',
	);
}

/**
 * Setup do tema.
 */
function casa_estamp_setup() {
	register_nav_menus(
		array(
			'primary' => __( 'Menu Principal', 'casa-estampa' ),
		)
	);

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );

	// Habilitar logo editavel no Customizer (Aparência > Personalizar > Identidade do site).
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 66,
			'width'       => 280,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
}
add_action( 'after_setup_theme', 'casa_estamp_setup' );

/**
 * Enqueue de estilos e scripts.
 */
function casa_estamp_scripts() {
	wp_enqueue_style( 'casa-estamp-google-fonts',
		'https://fonts.googleapis.com/css2?family=' . CASA_ESTAMP_FONT . '&display=swap',
		array(), null );
	wp_enqueue_style( 'casa-estamp-tabler-icons',
		'https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.35.0/dist/tabler-icons.min.css',
		array(), '3.35.0' );
	wp_enqueue_style( 'casa-estamp-style',
		get_stylesheet_uri(), array( 'casa-estamp-tabler-icons' ), CASA_ESTAMP_VERSION );
	wp_enqueue_script( 'casa-estamp-nav',
		get_template_directory_uri() . '/inc/nav.js', array(), CASA_ESTAMP_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'casa_estamp_scripts' );

/* ============================================================
   HELPERS DE LEITURA DOS VALORES DO THEME
   Sempre retorna o valor salvo no Customizer, ou o padrao.
   ============================================================ */
function casa_estamp_opt( $key ) {
	$defaults = casa_estamp_defaults();
	$val = get_theme_mod( 'ce_' . $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	return $val;
}

/** URL da logo (icone). Usa a logo do Customizer se definida, senao o SVG padrao. */
function casa_estamp_logo_icon_url() {
	$custom = get_theme_mod( 'cea_logo_icon' );
	if ( $custom ) {
		return $custom;
	}
	// Se o usuario definiu uma logo pelo Customizer nativo (custom_logo), usa como icone.
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$src = wp_get_attachment_image_url( $logo_id, 'full' );
		if ( $src ) {
			return $src;
		}
	}
	return casa_estamp_opt( 'logo_icon' );
}

/** URL da logo (lettering / marca escrita). */
function casa_estamp_logo_lettering_url() {
	$custom = get_theme_mod( 'cea_logo_lettering' );
	if ( $custom ) {
		return $custom;
	}
	return casa_estamp_opt( 'logo_lettering' );
}

/** Itens de menu padrao (usados apenas como fallback se nenhum menu estiver atribuido). */
function casa_estamp_menu_items() {
	return array(
		array( 'Início', home_url( '/' ) ),
		array( 'Papéis de Parede', home_url( '/papeis-de-parede/' ) ),
		array( 'Cortinas', home_url( '/cortinas/' ) ),
		array( 'Persianas', home_url( '/persianas/' ) ),
		array( 'Pisos', home_url( '/pisos/' ) ),
		array( 'Arquitetos', home_url( '/area-do-arquiteto/' ) ),
		array( 'Corporativo', home_url( '/corporativo/' ) ),
	);
}

function casa_estamp_menu_fallback() {
	echo '<ul class="navbar-nav">';
	foreach ( casa_estamp_menu_items() as $item ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $item[1] ), esc_html( $item[0] ) );
	}
	echo '</ul>';
}

/** Links do rodape ("Explore"): ate 7, usados apenas se nao houver menu. */
function casa_estamp_footer_menu() {
	$items = array_slice( casa_estamp_menu_items(), 0, 7 );
	$links = '';
	foreach ( $items as $item ) {
		$links .= sprintf( '<a href="%s">%s</a>', esc_url( $item[1] ), esc_html( $item[0] ) );
	}
	return $links;
}

/**
 * Roda o menu do WP (se existir) ou o fallback.
 * Usado no header e no footer.
 */
function casa_estamp_render_menu() {
	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'navbar-nav',
				'items_wrap'     => '<ul class="navbar-nav">%3$s</ul>',
				'fallback_cb'    => 'casa_estamp_menu_fallback',
			)
		);
	} else {
		casa_estamp_menu_fallback();
	}
}

/* ============================================================
   CUSTOMIZER - campos editaveis no painel (Personalizar)
   ============================================================ */
function casa_estamp_customize_register( $wp_customize ) {

	// -- Seção: Logo --
	$wp_customize->add_section( 'ce_logo', array(
		'title'    => __( 'Casa Estampa - Logo', 'casa-estampa' ),
		'priority' => 20,
	) );
	$wp_customize->add_setting( 'cea_logo_icon', array(
		'default'           => casa_estamp_opt( 'logo_icon' ),
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'cea_logo_icon', array(
		'label'    => __( 'Logo - ícone', 'casa-estampa' ),
		'section'  => 'ce_logo',
	) ) );

	$wp_customize->add_setting( 'cea_logo_lettering', array(
		'default'           => casa_estamp_opt( 'logo_lettering' ),
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'cea_logo_lettering', array(
		'label'    => __( 'Logo - lettering (marca escrita)', 'casa-estampa' ),
		'section'  => 'ce_logo',
	) ) );

	// -- Seção: Contato / CTA --
	$wp_customize->add_section( 'ce_contact', array(
		'title'    => __( 'Casa Estampa - Contato / CTA', 'casa-estampa' ),
		'priority' => 21,
	) );

	$fields = array(
		// id do setting => array( rótulo, sanitize, chave do default )
		'cea_cta_label'       => array( esc_html__( 'Texto do botão (CTA)', 'casa-estampa' ), 'sanitize_text_field', 'cta_label' ),
		'cea_cta_href'        => array( esc_html__( 'Link do WhatsApp (URL)', 'casa-estampa' ), 'esc_url_raw', 'cta_href' ),
		'cea_footer_contact'  => array( esc_html__( 'Contato do rodapé', 'casa-estampa' ), 'sanitize_text_field', 'footer_contact' ),
		'cea_footer_site'     => array( esc_html__( 'Site (rodapé)', 'casa-estampa' ), 'sanitize_text_field', 'footer_site' ),
		'cea_footer_city'     => array( esc_html__( 'Cidade (rodapé)', 'casa-estampa' ), 'sanitize_text_field', 'footer_city' ),
		'cea_footer_brand'    => array( esc_html__( 'Marca / copyright', 'casa-estampa' ), 'sanitize_text_field', 'footer_brand' ),
	);
	foreach ( $fields as $id => $cfg ) {
		$wp_customize->add_setting( $id, array(
			// Já nasce preenchido com o valor atual da Casa Estampa (editável depois).
			'default'           => casa_estamp_opt( $cfg[2] ),
			'sanitize_callback' => $cfg[1],
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $cfg[0],
			'section' => 'ce_contact',
			'type'    => 'text',
		) );
	}

	// -- Seção: Redes sociais --
	$wp_customize->add_section( 'ce_social', array(
		'title'    => __( 'Casa Estampa - Redes sociais', 'casa-estampa' ),
		'priority' => 22,
	) );
	$social = array(
		'cea_instagram' => array( esc_html__( 'Instagram (URL)', 'casa-estampa' ), 'social_instagram' ),
		'cea_facebook'  => array( esc_html__( 'Facebook (URL)', 'casa-estampa' ), 'social_facebook' ),
		'cea_pinterest' => array( esc_html__( 'Pinterest (URL)', 'casa-estampa' ), 'social_pinterest' ),
	);
	foreach ( $social as $id => $cfg ) {
		$wp_customize->add_setting( $id, array(
			'default'           => casa_estamp_opt( $cfg[1] ),
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( $id, array( 'label' => $cfg[0], 'section' => 'ce_social', 'type' => 'url' ) );
	}
}
add_action( 'customize_register', 'casa_estamp_customize_register' );

/** Atalhos para ler os valores do Customizer com fallback para os defaults do tema. */
function casa_estamp_custom( $id ) {
	$key = str_replace( 'cea_', '', $id );
	return get_theme_mod( $id, casa_estamp_opt( $key ) );
}

/** Link do CTA (WhatsApp). */
function casa_estamp_cta_href() {
	$v = get_theme_mod( 'cea_cta_href' );
	return $v ? $v : casa_estamp_opt( 'cta_href' );
}
